#include<stdio.h>
#include<math.h>
int det22(int *matrix)
{
	return (*(matrix)**(matrix+11))-(*(matrix+1)**(matrix+10));
}
int *cofactor(int *matrix,int j,int n)
{
	int temp[10][10],a=0,b=0,c=0,d=0;
	for(a=1;a<n;a++)
	{
		for(b=0;b<n;b++)
			if(b!=j)
				temp[c][d++]=*(matrix+(a*10)+b);
		c++;
		d=0;
	}
	return temp;
}

int det(int *matrix,int i,int j,int n)
{
	int k,deter=0;
	if(n==1)
		return *matrix;
	else if (n==2)
		return det22(matrix);
	else
		for(k=0;k<n;k++)
			deter+=pow(-1,k)**(matrix+k)*det(cofactor(matrix,k,n),i,j,n-1);
	return deter;
}



main()
{
	int matrix[10][10],i,j;
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
			scanf("%d",&matrix[i][j]);
	printf("%d",det(matrix,0,0,3));
	invert(matrix,3);
}

