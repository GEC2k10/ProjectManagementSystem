global a
a=8
