global a
print a
